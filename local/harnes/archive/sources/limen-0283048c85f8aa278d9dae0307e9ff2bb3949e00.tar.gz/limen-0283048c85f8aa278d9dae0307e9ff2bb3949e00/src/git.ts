import { spawnSync } from "node:child_process";
import { existsSync, realpathSync } from "node:fs";
import { basename, dirname, relative, resolve } from "node:path";
export type GitWorktree = { readonly path: string; readonly branch?: string; readonly detached: boolean };
type GitResult = { readonly stdout: string; readonly stderr: string; readonly status: number };
export function repoRoot(cwd: string): string {
	return requireGit(cwd, ["rev-parse", "--show-toplevel"]).stdout.trim();
}
export function workspaceRoot(cwd: string): string | undefined {
	const root = resolve(cwd);
	return existsSync(`${root}/.agents/limen`) && !isGitRepository(root) ? root : undefined;
}
export function limenRoot(cwd: string): string {
	return workspaceRoot(cwd) ?? repoRoot(cwd);
}
export function isGitRepository(cwd: string): boolean {
	return git(cwd, ["rev-parse", "--show-toplevel"]).status === 0;
}
export function workspaceRepository(workspace: string, name: string): string {
	if (!name || basename(name) !== name || name === "." || name === "..") throw new Error("--repo must name one immediate child repository");
	const repository = resolve(workspace, name);
	if (repoRoot(repository) !== repository) throw new Error(`--repo ${JSON.stringify(name)} must be a Git repository directly below the workspace`);
	return repository;
}
export function branchExists(cwd: string, branch: string): boolean {
	requireGit(cwd, ["check-ref-format", "--branch", branch]);
	return git(cwd, ["show-ref", "--verify", "--quiet", `refs/heads/${branch}`]).status === 0;
}
export function branchCommit(cwd: string, branch: string): string {
	return requireGit(cwd, ["rev-parse", `refs/heads/${branch}`]).stdout.trim();
}
export function listWorktrees(cwd: string): readonly GitWorktree[] {
	const fields = requireGit(cwd, ["worktree", "list", "--porcelain", "-z"]).stdout.split("\0");
	const worktrees: GitWorktree[] = [];
	let path: string | undefined;
	let branch: string | undefined;
	let detached = false;
	const finish = () => {
		if (path) worktrees.push({ path, detached, ...(branch ? { branch } : {}) });
		path = undefined;
		branch = undefined;
		detached = false;
	};
	for (const field of fields) {
		if (field.startsWith("worktree ")) {
			finish();
			path = field.slice(9);
		} else if (field.startsWith("branch refs/heads/")) branch = field.slice(18);
		else if (field === "detached") detached = true;
	}
	finish();
	return worktrees;
}
export function worktreeForBranch(cwd: string, branch: string): GitWorktree | undefined {
	return listWorktrees(cwd).find((worktree) => worktree.branch === branch);
}
export function addNewWorktree(cwd: string, path: string, branch: string): void {
	requireGit(cwd, ["worktree", "add", "-b", branch, path, "HEAD"]);
}
export function addBranchWorktree(cwd: string, path: string, branch: string): void {
	requireGit(cwd, ["worktree", "add", path, branch]);
}
export function addDetachedWorktree(cwd: string, path: string, ref: string): void {
	requireGit(cwd, ["worktree", "add", "--detach", path, ref]);
}
export function removeWorktree(cwd: string, path: string): void {
	requireGit(cwd, ["worktree", "remove", "--force", path]);
}
export function pruneWorktrees(cwd: string): void {
	requireGit(cwd, ["worktree", "prune"]);
}
export function headCommit(cwd: string): string {
	return requireGit(cwd, ["rev-parse", "HEAD"]).stdout.trim();
}
export function commitList(cwd: string, base: string, branch: string): string | undefined {
	const result = git(cwd, ["log", "--oneline", `${base}..${branch}`]);
	return result.status === 0 ? result.stdout.trimEnd() : undefined;
}
export function cleanWorktree(cwd: string): boolean {
	if (!existsSync(cwd)) return false;
	const result = git(cwd, ["--no-optional-locks", "status", "--porcelain"]);
	return result.status === 0 && result.stdout.trim() === "";
}
export function changedFileCount(cwd: string): number | undefined {
	if (!existsSync(cwd)) return undefined;
	const result = git(cwd, ["--no-optional-locks", "status", "--porcelain"]);
	return result.status !== 0 ? undefined : result.stdout.trim() === "" ? 0 : result.stdout.trimEnd().split("\n").length;
}
export function liveDiffstat(cwd: string, branch: string): string {
	const result = git(cwd, ["diff", "--stat", `HEAD...${branch}`]);
	return result.status === 0 ? result.stdout.trim() : `(unavailable: ${result.stderr.trim() || "git diff failed"})`;
}
export function ticketAuthor(cwd: string, ticket: string): { path: string; commit: string; name: string; email: string } {
	const root = repoRoot(cwd);
	const absolute = resolve(realpathSync(cwd), ticket);
	// Git reports the physical root (e.g. /private/var on macOS). Resolve directory
	// aliases too, but leave the filename literal so tracked symlinks keep their identity.
	const parent = dirname(absolute);
	const path = relative(root, resolve(existsSync(parent) ? realpathSync(parent) : parent, basename(absolute)));
	if (!path || path === ".." || path.startsWith("../")) throw new Error("ticket path must be a file inside this repository");
	if (git(root, ["cat-file", "-t", `HEAD:${path}`]).stdout.trim() !== "blob") throw new Error(`ticket author unavailable: ${path} is not a committed file at HEAD`);
	if (requireGit(root, ["rev-parse", "--is-shallow-repository"]).stdout.trim() === "true")
		throw new Error("ticket author unavailable: shallow history; fetch complete history first");
	// A copy files a new ticket; follow renames, but stop at copies.
	const [commit, name, email] = requireGit(root, ["log", "--follow", "--diff-filter=AC", "-1", "--format=%H%x00%an%x00%ae", "HEAD", "--", `:(literal)${path}`])
		.stdout.trimEnd()
		.split("\0");
	if (!commit || !name || !email) throw new Error(`ticket author unavailable: no creation author found for ${path}`);
	return { path, commit, name, email };
}
function requireGit(cwd: string, args: readonly string[]): GitResult {
	const result = git(cwd, args);
	if (result.status !== 0) throw new Error(result.stderr.trim() || result.stdout.trim() || `git ${args[0]} failed`);
	return result;
}
let gitBin = "";
function git(cwd: string, args: readonly string[]): GitResult {
	const run = (bin: string) => spawnSync(bin, args, { cwd: resolve(cwd), encoding: "utf8" });
	const miss = (error: Error | undefined) => !!error && "code" in error && error.code === "ENOENT";
	let result = run(gitBin || "git");
	if (miss(result.error)) result = run(gitBin || "git");
	if (miss(result.error) && !gitBin) {
		const fallback = ["/usr/bin/git", "/usr/local/bin/git", "/opt/homebrew/bin/git"].find((path) => existsSync(path));
		if (fallback) result = run((gitBin = fallback));
	} else if (!gitBin && !result.error) gitBin = "git";
	if (result.error) throw miss(result.error) ? new Error("git is not on PATH") : result.error;
	return { stdout: result.stdout ?? "", stderr: result.stderr ?? "", status: result.status ?? 1 };
}
