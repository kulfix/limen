import { execFileSync, spawnSync } from "node:child_process";
import { chmod, mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

export const LIMEN = fileURLToPath(new URL("../bin/limen", import.meta.url));

export type Scratch = {
	readonly root: string;
	readonly fakeBin: string;
	cleanup(): Promise<void>;
};

export async function scratchRepo(fakePi = defaultFakePi): Promise<Scratch> {
	const parent = await mkdtemp(join(tmpdir(), "limen-test-"));
	const root = join(parent, "repo");
	const fakeBin = join(parent, "bin");
	await createRepository(root);
	await mkdir(fakeBin);
	await writeFakePi(fakeBin, fakePi);
	return { root, fakeBin, cleanup: () => rm(parent, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 }) };
}
export async function scratchWorkspace(fakePi = defaultFakePi): Promise<Scratch & { readonly repositories: Readonly<Record<"api" | "web", string>> }> {
	const parent = await mkdtemp(join(tmpdir(), "limen-workspace-"));
	const root = join(parent, "workspace");
	const fakeBin = join(parent, "bin");
	const repositories = { api: join(root, "api"), web: join(root, "web") };
	await mkdir(root);
	await Promise.all(Object.values(repositories).map(createRepository));
	await mkdir(fakeBin);
	await writeFakePi(fakeBin, fakePi);
	return { root, fakeBin, repositories, cleanup: () => rm(parent, { recursive: true, force: true, maxRetries: 10, retryDelay: 100 }) };
}
async function createRepository(root: string): Promise<void> {
	await mkdir(root);
	git(root, "init", "-b", "main");
	git(root, "config", "user.email", "limen@example.test");
	git(root, "config", "user.name", "Limen Test");
	await writeFile(join(root, "README.md"), "scratch\n");
	git(root, "add", ".");
	git(root, "commit", "-m", "initial");
}

export function limen(scratch: Scratch, ...args: readonly string[]): { readonly stdout: string; readonly stderr: string; readonly status: number } {
	return runLimen(scratch, {}, args);
}
export function limenWithSession(scratch: Scratch, session: string, ...args: readonly string[]): { readonly stdout: string; readonly stderr: string; readonly status: number } {
	return runLimen(scratch, { PI_SESSION_ID: session, PI_SESSION_FILE: `/sessions/${session}.jsonl` }, args);
}
export function limenWithEnv(
	scratch: Scratch,
	added: NodeJS.ProcessEnv,
	...args: readonly string[]
): { readonly stdout: string; readonly stderr: string; readonly status: number } {
	return runLimen(scratch, added, args);
}
export function limenWithInput(scratch: Scratch, input: string, ...args: readonly string[]): { readonly stdout: string; readonly stderr: string; readonly status: number } {
	return runLimen(scratch, {}, args, input);
}
function runLimen(
	scratch: Scratch,
	addedEnvironment: NodeJS.ProcessEnv,
	args: readonly string[],
	input?: string,
): { readonly stdout: string; readonly stderr: string; readonly status: number } {
	const environment: NodeJS.ProcessEnv = {
		...process.env,
		PATH: `${scratch.fakeBin}:${process.env.PATH}`,
		LIMEN_PI: "pi",
	};
	for (const name of [
		"LIMEN_INTERNAL_RUN",
		"LIMEN_INTERNAL_HOSTED",
		"LIMEN_HOSTED",
		"LIMEN_JOB",
		"LIMEN_JOB_ID",
		"LIMEN_JOB_DIR",
		"LIMEN_WORKTREE",
		"LIMEN_TASK_FILE",
		"LIMEN_PREAMBLE",
		"LIMEN_CONTINUE_FILE",
		"LIMEN_HOSTED_START",
		"LIMEN_HOSTED_TARGET",
		"LIMEN_AGENT_NAME",
		"LIMEN_ROLE",
		"LIMEN_TIMEOUT_MS",
		"LIMEN_HANDSHAKE_MS",
		"LIMEN_HOSTED_STOP_WAIT_MS",
		"LIMEN_HOSTED_IDLE_MS",
		"LIMEN_HOSTED_START_MS",
		"LIMEN_MODEL",
		"LIMEN_PROVIDER",
		"LIMEN_THINKING",
		"LIMEN_ENGINE",
		"LIMEN_CLAUDE",
		"LIMEN_LABEL",
		"LIMEN_JOB_LABEL",
		"LIMEN_CONTEXT_ROOT",
		"LIMEN_PACKAGE",
		"LIMEN_PREFLIGHT",
		"LIMEN_PREPARE",
		"LIMEN_PREPARE_MS",
		"LIMEN_HERDR",
		"LIMEN_HUNK",
		"LIMEN_HOME",
		"LIMEN_VIEW",
		"PI_SESSION_ID",
		"PI_SESSION_FILE",
		"PI_PROVIDER",
		"PI_MODEL",
		"PI_REASONING_LEVEL",
		"HERDR_ENV",
		"HERDR_PANE_ID",
		"HERDR_TAB_ID",
		"HERDR_WORKSPACE_ID",
	])
		delete environment[name];
	environment.LIMEN_HERDR = "0";
	environment.LIMEN_HUNK = "0";
	environment.LIMEN_HOME = dirname(scratch.root);
	Object.assign(environment, addedEnvironment);
	const result = spawnSync(process.execPath, [LIMEN, ...args], {
		cwd: scratch.root,
		encoding: "utf8",
		env: environment,
		...(input !== undefined ? { input } : {}),
	});
	if (result.error) throw result.error;
	return { stdout: result.stdout ?? "", stderr: result.stderr ?? "", status: result.status ?? 1 };
}

export async function waitForState(root: string, id: string, expected: string, timeoutMs = 10_000): Promise<void> {
	const path = join(root, ".limen", "jobs", id, "state");
	const deadline = Date.now() + timeoutMs;
	while (Date.now() < deadline) {
		const state = await readFile(path, "utf8").then(
			(value) => value.trim(),
			() => "",
		);
		if (state === expected) return;
		await new Promise((resolve) => setTimeout(resolve, 25));
	}
	const job = join(root, ".limen", "jobs", id);
	const details = await Promise.all(["state", "log"].map(async (name) => `${name}: ${await readFile(join(job, name), "utf8").catch(() => "(missing)")}`));
	throw new Error(`job ${id} did not reach ${expected}\n${details.join("\n")}`);
}

export function git(cwd: string, ...args: readonly string[]): string {
	return execFileSync("git", args, { cwd, encoding: "utf8" }).trim();
}

export async function writeFakePi(fakeBin: string, source: string): Promise<void> {
	const path = join(fakeBin, "pi");
	const nl = source.indexOf("\n");
	const shebang = source.startsWith("#!") && nl !== -1 ? source.slice(0, nl + 1) : "";
	const body = shebang ? source.slice(shebang.length) : source;
	await writeFile(path, `${shebang}if (process.argv[2] === "--version") { console.log("0.0.0-test"); process.exit(0); }\n${body}`);
	await chmod(path, 0o755);
}

export async function writeFakeClaude(fakeBin: string, source: string): Promise<void> {
	const path = join(fakeBin, "claude");
	const nl = source.indexOf("\n");
	const shebang = source.startsWith("#!") && nl !== -1 ? source.slice(0, nl + 1) : "";
	const body = shebang ? source.slice(shebang.length) : source;
	await writeFile(path, `${shebang}if (process.argv[2] === "--version") { console.log("0.0.0-test (Claude Code)"); process.exit(0); }\n${body}`);
	await chmod(path, 0o755);
}

export function onlyJobId(stdout: string): string {
	const lines = stdout.trim().split("\n");
	const id = lines.at(-1);
	if (!id) throw new Error(`missing job id in ${JSON.stringify(stdout)}`);
	return id;
}

export const defaultFakePi = `#!/usr/bin/env node
const { appendFileSync, readFileSync, writeFileSync } = require("node:fs");
const { execFileSync } = require("node:child_process");
const args = process.argv.slice(2);
if (args[0] === "auth") process.exit(1);
const promptIndex = args.findIndex((value) => value.startsWith("@"));
const task = promptIndex >= 0 ? readFileSync(args[promptIndex].slice(1), "utf8") : "";
writeFileSync("pi-args.json", JSON.stringify(args));
writeFileSync("pi-task.txt", task);
writeFileSync("pi-env.json", JSON.stringify({ internal: process.env.LIMEN_INTERNAL_RUN, job: process.env.LIMEN_JOB, id: process.env.LIMEN_JOB_ID, label: process.env.LIMEN_JOB_LABEL, ...(process.env.LIMEN_CONTEXT_ROOT ? { contextRoot: process.env.LIMEN_CONTEXT_ROOT } : {}), herdr: Object.keys(process.env).filter((key) => key.startsWith("HERDR_")), pi: Object.keys(process.env).filter((key) => key.startsWith("PI_SESSION_") || key === "PI_PROVIDER" || key === "PI_MODEL" || key === "PI_REASONING_LEVEL") }));
console.log(JSON.stringify({ type: "agent_start" }));
console.log(JSON.stringify({ type: "tool_execution_start", toolName: "bash", args: { command: "git status" } }));
console.log(JSON.stringify({ type: "message_end", message: { role: "assistant", content: [{ type: "text", text: "fake pi completed" }] } }));
if (task.includes("make commit")) {
  writeFileSync("candidate.txt", "candidate\\n");
  execFileSync("git", ["add", "."]);
  execFileSync("git", ["commit", "-m", "candidate"]);
}
if (task.includes("fail now")) process.exit(7);
`;

export const defaultFakeClaude = `#!/usr/bin/env node
const { writeFileSync } = require("node:fs");
const args = process.argv.slice(2);
writeFileSync("claude-args.json", JSON.stringify(args));
const task = args[args.indexOf("-p") + 1] ?? "";
console.log(JSON.stringify({ type: "system", subtype: "init", session_id: "fake-claude-session" }));
console.log(JSON.stringify({ type: "assistant", message: { content: [{ type: "tool_use", name: "Bash", input: { command: "git status" } }] } }));
console.log(JSON.stringify({ type: "user", message: { content: [{ type: "tool_result" }] } }));
console.log(JSON.stringify({ type: "assistant", message: { content: [{ type: "text", text: "looked at the worktree" }] } }));
if (task.includes("fail now")) {
  console.log(JSON.stringify({ type: "result", subtype: "error_during_execution", is_error: true, result: "", session_id: "fake-claude-session" }));
  process.exit(1);
}
console.log(JSON.stringify({ type: "assistant", message: { content: [{ type: "text", text: "ship the narrow form; it costs the bulk import" }] } }));
console.log(JSON.stringify({ type: "result", subtype: "success", is_error: false, result: "ship the narrow form; it costs the bulk import", session_id: "fake-claude-session" }));
`;
