import assert from "node:assert/strict";
import { spawn, spawnSync } from "node:child_process";
import { chmod, copyFile, cp, mkdir, readFile, realpath, rm, stat, writeFile } from "node:fs/promises";
import { dirname, join } from "node:path";
import test, { type TestContext } from "node:test";
import { fileURLToPath } from "node:url";
import { finishEvent } from "../src/finish-receipt.ts";
import { finishWebhookEnv } from "../src/finish-webhook.ts";
import { git, onlyJobId, scratchRepo, waitForState } from "./scratch.ts";

const ROOT = fileURLToPath(new URL("..", import.meta.url));
const sender = `#!/bin/sh
exec node --input-type=commonjs - "$@" <<'SENDER'
const fs = require("node:fs");
const config = JSON.parse(fs.readFileSync(process.env.LIMEN_FINISH_WEBHOOK_ENV, "utf8"));
const job = process.env.LIMEN_JOB_DIR || process.env.TEST_JOB_DIR;
fs.appendFileSync(config.observations, JSON.stringify({ args: process.argv.slice(2), config: process.env.LIMEN_FINISH_WEBHOOK_ENV, state: fs.readFileSync(job + "/state", "utf8").trim(), finished: fs.existsSync(job + "/finished-at"), pid: fs.existsSync(job + "/pid") }) + "\\n");
console.log("synthetic-secret-must-not-leak");
console.error("synthetic-secret-must-not-leak");
if (config.receipts) fs.writeSync(3, config.receipts);
if (config.hang) {
  const child = require("node:child_process").spawn(process.execPath, ["-e", "setInterval(() => {}, 1000)"], { stdio: "ignore" });
  fs.writeFileSync(config.descendant, String(child.pid));
  process.on("SIGTERM", () => {});
  setInterval(() => {}, 1000);
  setTimeout(() => { child.kill("SIGKILL"); process.exit(99); }, 15000);
} else process.exit(config.exit || 0);
SENDER
`;
async function fixture(context: TestContext, fakePi?: string) {
	const scratch = await scratchRepo(fakePi);
	context.after(scratch.cleanup);
	const parent = dirname(scratch.root);
	const pkg = join(parent, "package");
	await mkdir(join(pkg, "bin"), { recursive: true });
	await cp(join(ROOT, "src"), join(pkg, "src"), { recursive: true });
	await cp(join(ROOT, "hook"), join(pkg, "hook"), { recursive: true });
	await cp(join(ROOT, "templates"), join(pkg, "templates"), { recursive: true });
	await copyFile(join(ROOT, "package.json"), join(pkg, "package.json"));
	await copyFile(join(ROOT, "bin/limen"), join(pkg, "bin/limen"));
	await writeFile(join(pkg, "bin/tony-finish-ping.sh"), sender, { mode: 0o755 });
	const env = { ...process.env };
	for (const key of Object.keys(env)) if (/^(LIMEN_|PI_|HERDR_|TONY_)/.test(key)) delete env[key];
	Object.assign(env, { PATH: `${scratch.fakeBin}:${process.env.PATH}`, HOME: parent, LIMEN_HOME: parent, LIMEN_HERDR: "0", LIMEN_HUNK: "0" });
	const command = (args: string[], extra: NodeJS.ProcessEnv = {}, cwd = scratch.root) => {
		const result = spawnSync(process.execPath, [join(pkg, "bin/limen"), ...args], { cwd, env: { ...env, ...extra }, encoding: "utf8", timeout: 15_000 });
		assert.equal(result.status, 0, result.stderr || result.error?.message);
		return result.stdout;
	};
	command(["init"]);
	const observations = join(parent, "observations");
	const config = async (path: string, extra: Record<string, unknown> = {}) => {
		await mkdir(dirname(path), { recursive: true });
		await writeFile(path, JSON.stringify({ observations, token: "synthetic-secret-must-not-leak", ...extra }), { mode: 0o600 });
		return realpath(path);
	};
	return { ...scratch, parent, pkg, env, command, config, observations };
}
async function delivery(job: string): Promise<string> {
	const deadline = Date.now() + 20_000;
	while (Date.now() < deadline) {
		const text = await readFile(join(job, "finish-webhook"), "utf8").catch(() => "");
		if (/^(accepted|failed):/.test(text)) return text;
		await new Promise((resolve) => setTimeout(resolve, 25));
	}
	throw new Error(`no terminal webhook status in ${job}: ${await readFile(join(job, "log"), "utf8").catch(() => "no log")}`);
}
async function observe(path: string) {
	return (await readFile(path, "utf8"))
		.trim()
		.split("\n")
		.map((line) => JSON.parse(line));
}
async function bareJob(root: string) {
	const job = join(root, ".limen/jobs/direct");
	await mkdir(job, { recursive: true });
	for (const [name, value] of Object.entries({ state: "running", label: "finish label", branch: "main", pid: "1", log: "" })) await writeFile(join(job, name), `${value}\n`);
	return job;
}
async function runModule(pkg: string, env: NodeJS.ProcessEnv, code: string): Promise<void> {
	const child = spawn(process.execPath, ["--input-type=module", "-e", code], { cwd: pkg, env, stdio: ["ignore", "ignore", "pipe"] });
	let stderr = "";
	child.stderr?.on("data", (chunk) => (stderr += chunk));
	await new Promise<void>((resolve, reject) => {
		child.once("error", reject);
		child.once("close", (code) => (code === 0 ? resolve() : reject(new Error(stderr || `exit ${code}`))));
	});
}

test("automatic delivery invokes the real canonical helper with synthetic dotenv and intercepted transport", async (context) => {
	const f = await fixture(context);
	await copyFile(join(ROOT, "bin/tony-finish-ping.sh"), join(f.pkg, "bin/tony-finish-ping.sh"));
	const config = join(f.root, ".limen/finish-webhook.env");
	await writeFile(config, "LIMEN_FINISH_WEBHOOK_URL='https://synthetic.example.invalid/finish'\nLIMEN_FINISH_WEBHOOK_AUTH='Bearer synthetic-only'\n", { mode: 0o600 });
	const transport = join(f.parent, "transport.mjs");
	await writeFile(
		transport,
		`import { appendFileSync, readFileSync } from 'node:fs'; globalThis.fetch = async (url, options) => { appendFileSync(${JSON.stringify(f.observations)}, JSON.stringify({ url: String(url), method: options.method, redirect: options.redirect, headers: options.headers, body: JSON.parse(options.body), state: readFileSync(process.env.LIMEN_JOB_DIR + '/state', 'utf8').trim() }) + '\\n'); return { status: 204 }; };`,
	);
	const id = onlyJobId(f.command(["spawn", "--detached", "--label", 'real helper "quoted" \\', "finish without manual ping"], { NODE_OPTIONS: `--import=${transport}` }));
	const job = join(f.root, ".limen/jobs", id);
	assert.match(await delivery(job), /^accepted:/);
	const request = (await observe(f.observations))[0];
	assert.deepEqual(request.body, { job: 'real helper "quoted" \\', status: "done", branch: (await readFile(join(job, "branch"), "utf8")).trim(), finishEvent: finishEvent(job) });
	assert.deepEqual(request.headers, { Authorization: "Bearer synthetic-only", "Content-Type": "application/json" });
	assert.equal(request.state, "done");
	assert.equal(request.method, "POST");
	assert.equal(request.redirect, "manual");
	assert.equal((await observe(f.observations)).length, 1);
	assert.doesNotMatch(await readFile(join(job, "log"), "utf8"), /synthetic-only|synthetic\.example/);
});

test("automatic delivery finds Limen's Node runtime when the inherited PATH cannot run node", async (context) => {
	const f = await fixture(context);
	await copyFile(join(ROOT, "bin/tony-finish-ping.sh"), join(f.pkg, "bin/tony-finish-ping.sh"));
	const job = await bareJob(f.root);
	const config = join(f.parent, "runtime.env");
	await writeFile(config, "LIMEN_FINISH_WEBHOOK_URL='https://synthetic.example.invalid/finish'\nLIMEN_FINISH_WEBHOOK_AUTH='Bearer synthetic-only'\n", { mode: 0o600 });
	await writeFile(join(job, "finish-webhook-env"), `${config}\n`);
	// Simulate a stale/missing node in a service PATH, independently of the host's installed binaries.
	await writeFile(join(f.fakeBin, "node"), "#!/bin/sh\nexit 127\n", { mode: 0o755 });
	const transport = join(f.parent, "runtime-transport.mjs");
	await writeFile(
		transport,
		`import { appendFileSync } from 'node:fs'; globalThis.fetch = async () => { appendFileSync(${JSON.stringify(f.observations)}, 'accepted\\n'); return { status: 204 }; };`,
	);
	await runModule(
		f.pkg,
		{ ...f.env, PATH: f.fakeBin, NODE_OPTIONS: `--import=${transport}` },
		`const { finalizeJob } = await import('./src/wrapper.ts'); await finalizeJob(${JSON.stringify(job)}, 'done', 'runtime probe');`,
	);
	assert.match(await delivery(job), /^accepted: sender exited 0 \(owner wake unobserved\)/);
	assert.equal(await readFile(f.observations, "utf8"), "accepted\n");
	assert.equal(await readFile(join(job, "state"), "utf8"), "done\n");
});

for (const firstStatus of [204, 503, "stall"]) {
	test(`automatic fan-out reaches two bot routes after terminal state; first HTTP ${firstStatus} stays HTTP-only`, async (context) => {
		const f = await fixture(context);
		await copyFile(join(ROOT, "bin/tony-finish-ping.sh"), join(f.pkg, "bin/tony-finish-ping.sh"));
		const targets = [
			{ url: "https://synthetic.example.invalid/grok-one", auth: "Bearer synthetic-one" },
			{ url: "https://synthetic.example.invalid/grok-two", auth: "Bearer synthetic-two" },
		];
		await writeFile(join(f.root, ".limen/finish-webhook.env"), `LIMEN_FINISH_WEBHOOK_TARGETS='${JSON.stringify(targets)}'\n`, { mode: 0o600 });
		const transport = join(f.parent, "transport.mjs");
		await writeFile(
			transport,
			`import { appendFileSync, readFileSync } from 'node:fs'; globalThis.fetch = async (url, options) => {
				appendFileSync(${JSON.stringify(f.observations)}, JSON.stringify({ url: String(url), auth: options.headers.Authorization, body: JSON.parse(options.body), state: readFileSync(process.env.LIMEN_JOB_DIR + '/state', 'utf8').trim() }) + '\\n');
				if (String(url).endsWith('/grok-one')) return ${firstStatus === "stall" ? "new Promise(() => {})" : `{ status: ${firstStatus} }`};
				return { status: 204 };
			};`,
		);
		const id = onlyJobId(f.command(["spawn", "--detached", "--label", "two bots", "finish without manual ping"], { NODE_OPTIONS: `--import=${transport}` }));
		const job = join(f.root, ".limen/jobs", id);
		const result = await delivery(job);
		assert.match(
			result,
			firstStatus === 204
				? /^accepted: sender exited 0 \(owner wake unobserved\)/
				: firstStatus === "stall"
					? /^failed: sender exceeded 3000ms; acceptance unknown/
					: /^failed: sender exited 1/,
		);
		const requests = await observe(f.observations);
		assert.deepEqual(
			requests.map(({ url, auth }) => ({ url, auth })),
			targets,
		);
		for (const request of requests) {
			assert.equal(request.state, "done");
			assert.deepEqual(request.body, { job: "two bots", status: "done", branch: (await readFile(join(job, "branch"), "utf8")).trim(), finishEvent: finishEvent(job) });
		}
		assert.equal(await readFile(join(job, "state"), "utf8"), "done\n");
		assert.doesNotMatch(result + (await readFile(join(job, "log"), "utf8")), /synthetic-one|synthetic-two|synthetic\.example/);
		// The receiver only accepts HTTP: no bot session/turn is created by this fixture or claimed by the receipt.
		assert.match(result, /Acceptance is not proof of owner wake/);
		const receipts = await readFile(join(job, "finish-webhook-targets"), "utf8");
		assert.equal((await stat(join(job, "finish-webhook-targets"))).mode & 0o777, 0o600);
		const inspections: string[] = [];
		for (const view of ["compact", "human"]) {
			const detail = f.command(["jobs", id], { LIMEN_VIEW: view });
			assert.match(detail, /configured: yes/);
			assert.ok(detail.includes(finishEvent(job)));
			assert.match(detail, /target 2: transport accepted · HTTP 2xx/);
			assert.match(
				detail,
				firstStatus === 204
					? /target 1: transport accepted/
					: firstStatus === "stall"
						? /target 1: transport unknown \(attempt started; no result\)/
						: /target 1: transport rejected · HTTP 5xx/,
			);
			assert.match(detail, /bot-turn: unobserved/);
			assert.doesNotMatch(detail + receipts, /synthetic-one|synthetic-two|synthetic\.example|Bearer|grok-one|grok-two/);
			inspections.push(detail);
		}
		// Offline file exchange, not actual Johnny/Tony history. The operator explicitly selects this source.
		const source = join(f.parent, "receiver-exports");
		await mkdir(source);
		await writeFile(
			join(source, "receivers.json"),
			JSON.stringify({
				version: 1,
				targets: [
					{ target: 1, receiver: "johnny" },
					{ target: 2, receiver: "tony" },
				],
			}),
		);
		const completed = {
			version: 1,
			event: finishEvent(job),
			target: 1,
			receiver: "johnny",
			state: "completed",
			session: "synthetic-session",
			turn: "synthetic-turn",
			completedAt: "2026-09-11T12:00:00.000Z",
		};
		await writeFile(join(source, `${finishEvent(job)}.1.json`), JSON.stringify(completed));
		await writeFile(join(source, `${finishEvent(job)}.2.json`), JSON.stringify({ ...completed, target: 2, receiver: "tony", event: finishEvent("wrong-job") }));
		const promoted: string[] = [];
		for (const view of ["compact", "human"]) {
			const detail = f.command(["jobs", id], { LIMEN_VIEW: view, LIMEN_FINISH_EVIDENCE_DIR: source });
			assert.match(detail, /target 1: transport [^\n]*bot-turn observed[^\n]*receiver johnny[^\n]*turn synthetic-turn/);
			assert.match(detail, /target 2: transport accepted[^\n]*bot-turn unobserved/);
			assert.doesNotMatch(detail, /synthetic-one|synthetic-two|synthetic\.example|Bearer|wrong-job/);
			promoted.push(detail);
		}
		await writeFile(join(source, `${finishEvent(job)}.2.json`), JSON.stringify({ ...completed, target: 2, receiver: "tony", turn: "synthetic-turn-2" }));
		const both: string[] = [];
		for (const view of ["compact", "human"]) {
			const detail = f.command(["jobs", id], { LIMEN_VIEW: view, LIMEN_FINISH_EVIDENCE_DIR: source });
			assert.match(detail, /target 2: transport accepted[^\n]*bot-turn observed[^\n]*receiver tony[^\n]*turn synthetic-turn-2/);
			assert.match(detail, /bot-turn: observed for 2 target\(s\)/);
			both.push(detail);
		}
		await runModule(f.pkg, f.env, `const { finalizeJob } = await import('./src/wrapper.ts'); await finalizeJob(${JSON.stringify(job)}, 'done', 'repeat');`);
		assert.equal((await observe(f.observations)).length, 2, "repeat finalization sends nothing");
		assert.equal(await readFile(join(job, "finish-webhook-targets"), "utf8"), receipts);
		if (process.env.LIMEN_TEST_FINISH_EVIDENCE) {
			const evidence = join(process.env.LIMEN_TEST_FINISH_EVIDENCE, `two-target-${firstStatus}`);
			await mkdir(evidence, { recursive: true });
			await writeFile(join(evidence, "targets.jsonl"), receipts);
			await writeFile(join(evidence, "aggregate.txt"), result);
			await writeFile(join(evidence, "inspection.txt"), inspections.join("\n\n"));
			await writeFile(join(evidence, "one-observed.txt"), promoted.join("\n\n"));
			await writeFile(join(evidence, "both-observed.txt"), both.join("\n\n"));
			await cp(source, join(evidence, "synthetic-exports"), { recursive: true });
			await writeFile(
				join(evidence, "proof.txt"),
				`job=${id}\nevent=${finishEvent(job)}\nautomatic requests=2; after repeat=2\nactual receiver turns=0; synthetic exports only\nBoth views: no export -> unobserved; matching target 1 + mismatched target 2 -> only target 1 observed; both matching -> both observed\n`,
			);
		}
	});
}

test("private receipt channel discards malformed, secret-bearing, duplicate and overflowing sender output", async (context) => {
	const f = await fixture(context);
	const job = await bareJob(f.root);
	const pending = { target: 1, at: "2026-09-11T12:00:00.000Z", transport: "pending", http: "none" };
	const accepted = { ...pending, transport: "accepted", http: "2xx" };
	const safe = `${JSON.stringify(pending)}\n${JSON.stringify(accepted)}\n`;
	const selected = await f.config(join(f.parent, "channel.env"), {
		receipts:
			safe +
			[accepted, { ...accepted, token: "synthetic-secret" }, { ...accepted, target: 65 }, { ...accepted, transport: "observed" }].map((value) => JSON.stringify(value)).join("\n") +
			`\n${"synthetic-secret".repeat(3000)}\n`,
	});
	await writeFile(join(job, "finish-webhook-env"), `${selected}\n`);
	await runModule(
		f.pkg,
		{ ...f.env, TEST_JOB_DIR: job },
		`const { finalizeJob } = await import('./src/wrapper.ts'); await finalizeJob(${JSON.stringify(job)}, 'done', 'channel');`,
	);
	// The OS may coalesce the oversized stream: dropping the entire chunk is also safe.
	const retained = await readFile(join(job, "finish-webhook-targets"), "utf8").catch(() => "");
	assert.ok(["", `${JSON.stringify(pending)}\n`, safe].includes(retained), retained);
	assert.doesNotMatch(retained + (await readFile(join(job, "log"), "utf8")), /synthetic-secret|observed"|target":65/);
});

test("detached completion sends exact arguments only after durable state using an absolute explicit config snapshot", async (context) => {
	const f = await fixture(context);
	await f.config(join(f.root, ".limen/finish-webhook.env"), { exit: 99 });
	const selected = await f.config(join(f.root, "private config.env"));
	const label = 'quote " slash \\ $(no-shell) ☃';
	const branch = 'limen/quote"branch';
	const id = onlyJobId(f.command(["spawn", "--detached", "--label", label, "--branch", branch, "finish without manual ping"], { LIMEN_FINISH_WEBHOOK_ENV: "private config.env" }));
	const job = join(f.root, ".limen/jobs", id);
	assert.match(await delivery(job), /^accepted: sender exited 0 \(owner wake unobserved\)/);
	assert.deepEqual(await observe(f.observations), [{ args: [label, "done", branch], config: selected, state: "done", finished: true, pid: false }]);
	assert.equal(await readFile(join(job, "finish-webhook-env"), "utf8"), `${selected}\n`);
	assert.equal((await stat(join(job, "finish-webhook-env"))).mode & 0o777, 0o600);
	assert.doesNotMatch(await readFile(join(job, "log"), "utf8"), /synthetic-secret/);
	assert.equal(await readFile(join(job, "notify/ready"), "utf8"), "1\n");
	assert.match(f.command(["jobs", id]), /finish webhook: accepted:/);
});

test("canonical project config is selected from a linked worktree, never the worktree-local decoy", async (context) => {
	const f = await fixture(context);
	const selected = await f.config(join(f.root, ".limen/finish-webhook.env"));
	const linked = join(f.parent, "linked");
	git(f.root, "worktree", "add", "-b", "linked", linked);
	await f.config(join(linked, ".limen/finish-webhook.env"), { exit: 99 });
	assert.equal(finishWebhookEnv(linked, linked, ""), "");
	const id = onlyJobId(f.command(["spawn", "--detached", "finish"], {}, linked));
	const job = join(linked, ".limen/jobs", id);
	assert.match(await delivery(job), /^accepted:/);
	assert.equal(await readFile(join(job, "finish-webhook-env"), "utf8"), `${selected}\n`);
	assert.equal((await observe(f.observations))[0].config, selected);
});

test("workspace jobs use the coordinator project's config rather than a child repository destination", async (context) => {
	const f = await fixture(context);
	f.command(["workspace", "init"], {}, f.parent);
	const selected = await f.config(join(f.parent, ".limen/finish-webhook.env"));
	await f.config(join(f.root, ".limen/finish-webhook.env"), { exit: 99 });
	const id = onlyJobId(f.command(["spawn", "--detached", "--repo", "repo", "finish"], {}, f.parent));
	const job = join(f.parent, ".limen/jobs", id);
	assert.match(await delivery(job), /^accepted:/);
	assert.equal(await readFile(join(job, "finish-webhook-env"), "utf8"), `${selected}\n`);
	assert.equal((await observe(f.observations))[0].config, selected);
});

test("a retired env-path override does not opt an unconfigured job into delivery", async (context) => {
	const f = await fixture(context);
	const ignored = await f.config(join(f.parent, "ignored.env"));
	const id = onlyJobId(f.command(["spawn", "--detached", "finish"], { TONY_FINISH_WEBHOOK_ENV: ignored }));
	await waitForState(f.root, id, "done");
	const job = join(f.root, ".limen/jobs", id);
	await runModule(f.pkg, f.env, `const { finalizeJob } = await import('./src/wrapper.ts'); await finalizeJob(${JSON.stringify(job)}, 'done', 'repeat');`);
	await assert.rejects(readFile(join(job, "finish-webhook-env")));
	await assert.rejects(readFile(join(job, "finish-webhook-attempt")));
	await assert.rejects(readFile(f.observations));
});

test("unconfigured jobs never inherit home config or a later finalizer environment", async (context) => {
	const f = await fixture(context);
	const homeConfig = await f.config(join(f.parent, ".overment/finish-webhook.env"));
	const id = onlyJobId(f.command(["spawn", "--detached", "finish"]));
	await waitForState(f.root, id, "done");
	const job = join(f.root, ".limen/jobs", id);
	await runModule(
		f.pkg,
		{ ...f.env, LIMEN_FINISH_WEBHOOK_ENV: homeConfig },
		`const { finalizeJob } = await import('./src/wrapper.ts'); await finalizeJob(${JSON.stringify(job)}, 'failed', 'repeat');`,
	);
	await assert.rejects(readFile(join(job, "finish-webhook-env")));
	await assert.rejects(readFile(join(job, "finish-webhook-attempt")));
	await assert.rejects(readFile(f.observations));
});

test("concurrent processes and repeated finalization make one automatic attempt; failure preserves outcome and routing", async (context) => {
	const f = await fixture(context);
	const job = await bareJob(f.root);
	const selected = await f.config(join(f.parent, "private.env"), { exit: 22 });
	await writeFile(join(job, "finish-webhook-env"), `${selected}\n`);
	await mkdir(join(job, "notify/subscribers"), { recursive: true });
	await writeFile(join(job, "notify/subscribers/owner"), "subscribed\n");
	const code = `const { finalizeJob } = await import('./src/wrapper.ts'); await finalizeJob(${JSON.stringify(job)}, 'failed', 'synthetic worker failure');`;
	await Promise.all(Array.from({ length: 4 }, () => runModule(f.pkg, { ...f.env, TEST_JOB_DIR: job }, code)));
	assert.match(await delivery(job), /^failed: sender exited 22/);
	assert.match(await readFile(join(job, "finish-webhook"), "utf8"), /Manual finish-ping retry:/);
	await runModule(f.pkg, { ...f.env, TEST_JOB_DIR: job }, code);
	assert.equal((await observe(f.observations)).length, 1);
	assert.equal(await readFile(join(job, "state"), "utf8"), "failed\n");
	assert.equal(await readFile(join(job, "notify/subscribers/owner"), "utf8"), "subscribed\n");
	assert.doesNotMatch(await readFile(join(job, "finish-webhook"), "utf8"), /synthetic-secret/);
	assert.doesNotMatch(await readFile(join(job, "log"), "utf8"), /synthetic-secret/);
});

test("hosted supervisor completion uses the same automatic path without a worker manual ping", async (context) => {
	const f = await fixture(context);
	const job = await bareJob(f.root);
	const selected = await f.config(join(f.parent, "hosted.env"));
	await writeFile(join(job, "finish-webhook-env"), `${selected}\n`);
	await writeFile(join(job, "session-ended"), "1\n");
	const herdr = join(f.fakeBin, "herdr");
	await writeFile(herdr, '#!/usr/bin/env node\nconsole.log(JSON.stringify({ result: { status: "done" } }));\n');
	await chmod(herdr, 0o755);
	await runModule(
		f.pkg,
		{ ...f.env, LIMEN_HERDR: herdr, LIMEN_JOB_DIR: job, LIMEN_HOSTED_TARGET: "synthetic:p1" },
		"const { runHostedSupervisor } = await import('./src/supervisor.ts'); await runHostedSupervisor();",
	);
	assert.match(await delivery(job), /^accepted:/);
	assert.equal((await observe(f.observations))[0].state, "done");
});

test("hanging sender and its descendant are killed within shutdown grace without changing stopped state", async (context) => {
	const f = await fixture(context);
	const job = await bareJob(f.root);
	const descendant = join(f.parent, "descendant");
	const selected = await f.config(join(f.parent, "hang.env"), { hang: true, descendant });
	await writeFile(join(job, "finish-webhook-env"), `${selected}\n`);
	const started = Date.now();
	await runModule(
		f.pkg,
		{ ...f.env, TEST_JOB_DIR: job },
		`const { finalizeJob } = await import('./src/wrapper.ts'); await finalizeJob(${JSON.stringify(job)}, 'stopped', 'bounded stop');`,
	);
	assert.ok(Date.now() - started < 4_500, "sender must leave room within the wrapper's 5s grace");
	assert.match(await delivery(job), /^failed: sender exceeded 3000ms; acceptance unknown/);
	assert.equal(await readFile(join(job, "state"), "utf8"), "stopped\n");
	const pid = Number(await readFile(descendant, "utf8"));
	const status = spawnSync("ps", ["-p", String(pid), "-o", "stat="], { encoding: "utf8" });
	assert.ok(status.status !== 0 || status.stdout.trim().startsWith("Z"), `sender descendant is still running: ${status.stdout}`);
});

test("an exhausted shutdown budget records not sent without launching the helper", async (context) => {
	const f = await fixture(context);
	const job = await bareJob(f.root);
	const selected = await f.config(join(f.parent, "late.env"));
	await writeFile(join(job, "finish-webhook-env"), `${selected}\n`);
	await runModule(
		f.pkg,
		{ ...f.env, TEST_JOB_DIR: job },
		`const { finalizeJob } = await import('./src/wrapper.ts'); await finalizeJob(${JSON.stringify(job)}, 'stopped', 'late stop', Date.now() - 1);`,
	);
	assert.match(await delivery(job), /^failed: no shutdown time remains; not sent/);
	assert.equal(await readFile(join(job, "state"), "utf8"), "stopped\n");
	await assert.rejects(readFile(f.observations));
});

test("missing config and unavailable sender fail safely, while an interrupted claim is never retried automatically", async (context) => {
	const f = await fixture(context);
	const job = await bareJob(f.root);
	await writeFile(join(job, "finish-webhook-env"), `${join(f.parent, "missing.env")}\n`);
	const finalize = `const { finalizeJob } = await import('./src/wrapper.ts'); await finalizeJob(${JSON.stringify(job)}, 'done', 'finish');`;
	await runModule(f.pkg, { ...f.env, TEST_JOB_DIR: job }, finalize);
	assert.match(await delivery(job), /^failed: sender exited 1/);
	assert.doesNotMatch(await readFile(join(job, "log"), "utf8"), /ENOENT|missing\.env|synthetic-secret/);
	await rm(join(job, "finish-webhook-attempt"));
	await writeFile(join(job, "state"), "running\n");
	await rm(join(f.pkg, "bin/tony-finish-ping.sh"));
	await runModule(f.pkg, { ...f.env, TEST_JOB_DIR: job }, finalize);
	assert.match(await delivery(job), /^failed: sender could not start/);
	const receipt = await readFile(join(job, "finish-webhook"), "utf8");
	await writeFile(join(job, "state"), "running\n");
	await runModule(f.pkg, { ...f.env, TEST_JOB_DIR: job }, finalize);
	assert.equal(await readFile(join(job, "finish-webhook"), "utf8"), receipt);
	await assert.rejects(readFile(f.observations));
});

test("detached exhaustion records a bounded delivery failure before its self-kill grace", async (context) => {
	const f = await fixture(context, '#!/usr/bin/env node\nprocess.on("SIGTERM", () => {}); setInterval(() => {}, 1000);\n');
	const selected = await f.config(join(f.parent, "exhaust.env"), { hang: true, descendant: join(f.parent, "descendant") });
	const id = onlyJobId(f.command(["spawn", "--detached", "--timeout", "1s", "exhaust"], { LIMEN_FINISH_WEBHOOK_ENV: selected }));
	const job = join(f.root, ".limen/jobs", id);
	assert.match(await delivery(job), /^failed: (sender exceeded \d+ms; acceptance unknown|no shutdown time remains; not sent)/);
	assert.equal(await readFile(join(job, "state"), "utf8"), "failed\n");
	const log = await readFile(join(job, "log"), "utf8");
	assert.match(log, /failed: timeout after 1000ms/);
	assert.match(log, /finish webhook: failed:/);
});

test("continuation retains only its parent's config path even when the caller selects another destination", async (context) => {
	const f = await fixture(context);
	const selected = await f.config(join(f.parent, "first.env"));
	const other = await f.config(join(f.parent, "other.env"), { exit: 99 });
	const id = onlyJobId(f.command(["spawn", "--detached", "finish"], { LIMEN_FINISH_WEBHOOK_ENV: selected }));
	const parentJob = join(f.root, ".limen/jobs", id);
	await delivery(parentJob);
	await mkdir(join(parentJob, "session"));
	await writeFile(join(parentJob, "session/one.jsonl"), "{}\n");
	const next = onlyJobId(f.command(["continue", "--detached", id, "follow up"], { LIMEN_FINISH_WEBHOOK_ENV: other }));
	const job = join(f.root, ".limen/jobs", next);
	assert.match(await delivery(job), /^accepted:/);
	assert.equal(await readFile(join(job, "finish-webhook-env"), "utf8"), `${selected}\n`);
	assert.equal((await observe(f.observations)).length, 2);
	assert.equal((await observe(f.observations))[1].config, selected);
});
